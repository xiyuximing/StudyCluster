public class MyTest {
    public static void main(String[] args) {
        System.out.println(java.util.UUID.randomUUID().toString());
    }
}
